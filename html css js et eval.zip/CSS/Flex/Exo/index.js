function openMenu() {
  let menu = document.getElementById("link");
  if (menu.style.display === "block") {
    menu.style.display = "none";
    menu.className = "";
  } else {
    menu.style.display = "block";
    menu.className = "active";
  }

  const hamburger = document.getElementById("hamburger");

  // Toggle la classe 'open' pour transformer le hamburger en croix
  hamburger.classList.toggle("open");

  // Toggle l'affichage du menu
  menu.style.display = nav.style.display === "block" ? "none" : "block";
}
