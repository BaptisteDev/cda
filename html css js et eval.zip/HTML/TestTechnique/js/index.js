// Ouverture du menu
function openMenu() {
  let menu = document.getElementById("menu");
  if (menu.style.display === "block") {
    menu.style.display = "none";
    menu.className = "";
  } else {
    menu.style.display = "block";
    menu.className = "active";
  }

  const hamburger = document.getElementById("hamburger");
  const nav = document.querySelector("nav");

  // Toggle la classe 'open' pour transformer le hamburger en croix
  hamburger.classList.toggle("open");

  // Toggle l'affichage du menu
  nav.style.display = nav.style.display === "block" ? "none" : "block";
}

// Include du header
fetch("../html/layouts/header.html")
  .then((response) => response.text())
  .then((data) => {
    document.getElementById("header").innerHTML = data;
  });
window.scrollTo(0, 0);
// Include du footer
fetch("../html/layouts/footer.html")
  .then((response) => response.text())
  .then((data) => {
    document.getElementById("footer").innerHTML = data;
  });

// Include du modal de login
fetch("../html/modal/modalLogin.html")
  .then((response) => response.text())
  .then((data) => {
    document.getElementById("modalLoginAffichage").innerHTML = data;
  });

// Include du modal de register
fetch("../html/modal/modalRegister.html")
  .then((response) => response.text())
  .then((data) => {
    document.getElementById("modalRegisterAffichage").innerHTML = data;
  });

// Include du Formulaire de contact
fetch("../html/form/contactForm.html")
  .then((response) => response.text())
  .then((data) => {
    document.getElementById("contact").innerHTML = data;
  });

// Include du modal Information
fetch("../html/modal/modalInformation.html")
  .then((response) => response.text())
  .then((data) => {
    document.getElementById("modalInformationAffichage").innerHTML = data;
  });

// Formulaire de veirificatin sans REGEX, simplement de l'affichage des erreur de l'utilisateur
// Récuperation de nos input
// On verifie si ils sont vide ou non
// Si tout est bon on affiche une alert
// Sinon on affiche les erreurs grace a VerifValue
function verifFormOnChange() {
  let email = document.getElementById("email");
  let name = document.getElementById("name");
  let firstname = document.getElementById("firstname");
  let phone = document.getElementById("phone");
  let message = document.getElementById("message");
  let erreur = document.getElementById("erreur");
  // Email verif
  verifValue(email);
  // Name verif
  verifValue(name);
  // Firtsname verif
  verifValue(firstname);
  // Phone verif
  verifValue(phone);
  // Message verif
  verifValue(message);
  erreur.style.color = "red";
}

function verifValue(x) {
  if (x.value == "") {
    x.style.border = "1px solid red";
    erreur.innerHTML = "Le formulaire n'est pas correctement remplis";
  } else if (x.value != null) {
    x.style.border = "1px solid green";
    erreur.innerHTML = "";
  }
}

function verifFormOnClick() {
  let email = document.getElementById("email");
  let name = document.getElementById("name");
  let firstname = document.getElementById("firstname");
  let phone = document.getElementById("phone");
  let message = document.getElementById("message");
  let erreur = document.getElementById("erreur");
  if (
    email.value != "" &&
    name.value != "" &&
    firstname.value != "" &&
    phone.value != "" &&
    message.value != ""
  ) {
    alert("Merci, votre demande de contact a bien été envoyer!");
  }
}
window.onload = function () {
  document.querySelector("body").style.opacity = 1;
};

// Modal

function open(modal) {
  modal.showModal();
}

function close(modal) {
  modal.close();
}

function openModal(value) {
  if (value === "login") {
    const modal = document.getElementById("modalLogin");
    open(modal);
  } else if (value === "register") {
    const modal = document.getElementById("modalRegister");
    open(modal);
  }
}

function closeModal(value) {
  if (value === "login") {
    const modal = document.getElementById("modalLogin");
    close(modal);
  } else if (value === "register") {
    const modal = document.getElementById("modalRegister");
    close(modal);
  } else if (value === "information") {
    const modal = document.getElementById("modalInformation");
    close(modal);
  }
}

// Gestion des données

function submitForm(event) {
  event.preventDefault();

  const form = document.getElementById("myForm");
  const jsonDataElement = document.getElementById("jsonData");
  const modal = document.getElementById("modalInformation");

  // Récupérer les données du formulaire
  const formData = new FormData(form);
  const data = {};
  formData.forEach((value, key) => {
    data[key] = value;
  });

  // Vider le contenu précédent du modal
  jsonDataElement.innerHTML = "";

  // Créer un affichage propre pour chaque donnée
  for (const key in data) {
    if (data.hasOwnProperty(key)) {
      const listItem = document.createElement("div");
      listItem.classList.add("data-item");

      // Créer une étiquette et la valeur correspondante
      const label = document.createElement("strong");
      label.textContent = `${capitalizeFirstLetter(key)}:`;

      const value = document.createElement("span");
      value.textContent = ` ${data[key]}`;

      // Ajouter l'étiquette et la valeur à l'élément de la liste
      listItem.appendChild(label);
      listItem.appendChild(value);

      // Ajouter l'élément de la liste au modal
      jsonDataElement.appendChild(listItem);
    }
  }

  // Ouvrir le modal
  modal.showModal();
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
