// le premier indice d'un tableau est 0
let users = ["John", "Jane", "Paul"];
// récupérer la taille d'un tableau
console.log(users.length);

// accéder à un élément du tableau
console.log(users[1]);

// ajouter un élément en fin de tableau
users.push("Lisa");

// ajouter un élément en début de tableau
users.unshift("Peter");
console.log(users);

// récupére les éléments situés entre l'indice 1 et (3 non inclus)
let connectedUsers = users.slice(1, 3);
console.log(connectedUsers);

// supprimer le dernier élément
users.pop();
console.log(users);

// Boucle Tableau

let countries = ["Usa", "France", "Italy", "Spain"];

// boucle forEach pour éxécuter une action sur chaque élément
countries.forEach((country) => console.log(country.toUpperCase()));
console.log(countries);

//map on crée un nouveau tableau transformé
let notes = [12, 16, 8, 17, 5];
let newNote = notes.map((note) => note - 2);
console.log(newNote);

// filter permet de filtrer les éléments d'un tableau
let goodNote = notes.filter((note) => note > 10);
console.log(goodNote);
