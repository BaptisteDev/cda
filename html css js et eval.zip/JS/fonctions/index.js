// déclaration de fonction
function salueVisiteur(){ 
        console.log("Bienvenue dans de monde enchantée");
}

salueVisiteur(); // Appelle (ou invoque) la fonction

// Depuis es6 fonction fléchée
// Fonction fléchée
const lanceSort = () =>{
    console.log("Abracadabra");
    
}
lanceSort();

// Fonction avec paramètre(s)
function sayMyName(name, age = 25){
    console.log("Say my name !");
    console.log(name + " ...");
    console.log(age + " ans");
}

// on invoque la fonction avec un argument (ou paramètre)
sayMyName("Heisenberg", 45);
sayMyName("Jesse"
);


// Utilisation de rest(...)
// a utiliser en dernier paramètre et lorque son nombre est variable, dans cet exemple le nombre de notes
function calculMoyenne(nom, ...notes){
    // Initialisation d'une variable pour la somme
    let somme = 0;
    // Boucle for pour récupérer le total des notes
    for(i = 0; i < notes.length; i++){ // On démarre à l'indice 0
        somme +=notes[i];   
    }
    // Calcul de la moyenne 
    let moyenne = somme / notes.length;
    // Affichage de la moyenne 
    console.log("La moyenne de : " + nom + " est de : " + moyenne.toFixed(2)) ;
}

calculMoyenne("Jane", 15,12,14,13,8)
calculMoyenne("John", 12,14,3,13,8,20,17)
