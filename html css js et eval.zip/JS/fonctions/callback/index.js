
// on récupére une référence dans notre page HTML
// simplement un élément de jotre page sur leqeul on veut interagir

let myButton = document.querySelector('.firstBtn');

// Ecoute d'un évenement
myButton.addEventListener('click', () => {
    alert('Bravo vous avez cliqué')
})