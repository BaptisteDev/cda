// Function qui prend en paramètre l'événement et les participants
// la fonction affiche la l'evement la liste des participants en fonction de leur place de départ
function affichageEvenement(evenement, ...participants){
    console.log("L'événement : " + evenement + " aura " +  participants.length + " participants");
    console.log("Voici la liste : ");
    numeroParticipant = 1;
    for(let i = 0; i < participants.length; i++){
       console.log("Le participant numéro : " + numeroParticipant + "  "+ participants[i]);
       numeroParticipant++;
    }
}

affichageEvenement("Marathon de Paris", "Fabrice", "Sophie", "Jean-Claude", "Marie","Jean")