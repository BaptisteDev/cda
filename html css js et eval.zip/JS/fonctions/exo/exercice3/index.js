// Function qui vérifie la valeur entrer par l'utilisateur et l'affiche dans la console
// event.preventDefault(); evite l'envoi du formulaire
function affichageMessage(event) {
  event.preventDefault();
  let saisie = document.querySelector("#userSaisie");
  let message = document.querySelector(".message");
  console.log(saisie.value);
  message.style.color = "green";
  message.style.fontWeight = "bold";
  message.innerHTML = "Le message que vous avez saisie : " + saisie.value;
}

// event qui permet d'alerter l'utilisateur si il click sur le btn
let myButton = document.querySelector(".btn");

myButton.addEventListener("click", () => {
  alert("Attention vous allez changez de page");
});
