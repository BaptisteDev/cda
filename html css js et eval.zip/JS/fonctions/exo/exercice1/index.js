// Function qui calcul la somme de deux chiffres ou nombres
// Dans cette exemple a = chiffre 1 et b chiffre 2
// On retourne le resultat grace a return
function calculSomme(a, b){
    return a+b;
}

// Appelle de la fonction calculSomme 3 fois avec différente valeur
console.log(calculSomme(5,21));
console.log(calculSomme(52,421));
console.log(calculSomme(34,44));