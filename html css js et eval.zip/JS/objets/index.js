// let voiture = {
//   marque: "Audi",
//   prix: 25000,
//   automatic: false,
//   image:
//     "https://images.unsplash.com/photo-1567808291548-fc3ee04dbcf0?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
//   options: {
//     gps: true,
//     clim: "oui",
//   },
// };

// // on ajoute une clé à sa valeur qui n'était pas existante
// voiture.couleur = "noire";
// console.log(voiture);

// // modification d'une valeur dans l'objet
// voiture.options.gps = false;

// // accèder aux valeurs de l'objet
// console.log(voiture.prix);
// // console.log(voiture["automatic"]); on n'utilise pas
// console.log(voiture.options.gps);

// // Manipulations

// let voitureManip = {
//   marque: "Audi",
//   prix: 25000,
//   automatic: false,
//   image:
//     "https://images.unsplash.com/photo-1567808291548-fc3ee04dbcf0?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
//   options: {
//     gps: true,
//     clim: "oui",
//   },
// };

// // récupérer les clés de l'objet
// console.log(Object.keys(voitureManip));

// // récupérer les valeurs de l'objet
// console.log(Object.values(voitureManip));

// // récupérer la totalité des clés et des valeurs de l'objet
// console.log(Object.entries(voitureManip));

// // déstructurer un objet
// // let marque = voiture.marque;
// // let prix = voiture.prix;
// // let image = voiture.image;

// let {
//   marque,
//   prix,
//   image,
//   options: { gps, clim },
// } = voiture;
// console.log(clim);

const voitures = [
  {
    marque: "Toyota",
    modele: "Corolla",
    annee: 2018,
    couleurs: ["bleu", "noir"],
  },
  {
    marque: "Honda",
    modele: "Civic",
    annee: 2020,
    couleurs: ["rouge", "blanc"],
  },
  {
    marque: "Ford",
    modele: "Mustang",
    annee: 2015,
    couleurs: ["jaune", "noir"],
  },
  {
    marque: "Audi",
    modele: "A4",
    annee: 2021,
    couleurs: ["blanc", "noir"],
  },
];

// il est possible de cumuler les méthodes filter et map
const voituresRecents = voitures
  .filter((voiture) => voiture.annee > 2017)
  .map((voiture) => console.log(voiture.marque));

//   La méthode find() retourne le premier élément du tableau qui correspond à la condition spécifiée sinon elle retourne undefined.
const voitureCivic = voitures.find((voiture) => voiture.modele === "Civic");
console.log(voitureCivic);

const voiture = voitures[0];
const disponibleNoir = voiture.couleurs.includes("noir");
console.log(disponibleNoir);

// includes() permet de vérifier si un tableau contient un élément spécifique.

const blackCar = voitures.filter((car) => car.couleurs.includes("noir"));
console.log(blackCar);
