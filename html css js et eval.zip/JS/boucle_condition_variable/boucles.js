// boucle for

// for (let i = 1; i <= 9; i++) {
//   console.log(i);
// }

// afficher en console la table de multiplication de 5

for (let i = 0; i <= 10; i++) {
  console.log(i + " multiplié par 5 = " + i * 5);
}
