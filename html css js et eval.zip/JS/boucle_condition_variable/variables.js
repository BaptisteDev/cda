// Const quand la valeur ne change pas
// Let quand on pense que la valeur va être "dynamique"
// Ne plus utilisé VAR
console.log("Test");

let year = 2025;
year = 2026;
console.log(year);

const secu = 17004;

console.log(secu);

// Type primitif

let name = "Jane"; // Chaine de caractère = > String
let age = 18; // nombre => number
let married = false; // boolen true ou false
//null et undefined

let a = 1;

a = a * 5; // + - * /
a *= 5;

a = a + 1;
a++;

console.log(a);

// Opérateurs de comparaison ET

console.log(true && true); // retourne true
console.log(true && false); // retourne false
console.log(false && true); // retourne false
console.log(false && false); // retourne false

// Opérateurs de comparaison OU

console.log(true || true); // retourne true
console.log(true || false); // retourne true
console.log(false || true); // retourne true
console.log(false || false); // retourne false

// Vérification
let b = "4";
let c = 4;
console.log(b == c); // retourne true

//Toujours à priviliégier
console.log(b === c); // retourne false
console.log(b < c); // retourne false
console.log(b > c); // retourne false
console.log(b >= c); // retourne true
