// if else

if ("condition") {
  // Si la condition est vrai on réalise cette tache
} else {
  // Sinon je fais autre chose
}

// Vous créez un variable pour un nom
// Vous créez une variable age

// condition à réaliser si l'age est supérieur ou égal à 18
// vous indiquez en console 'Bienvenue + le nom'
// Sinon 'accès interdit'

let age = 19;
let name = "Baptiste";

if (age >= 18) {
  console.log("Bienvenue " + name);
} else {
  console.log("Accès interdit");
}

if ("condition") {
  // Si la condition est vrai on réalise cette tache
} else if ("condition") {
  // On réalise une autre tâche
} else {
  // Sinon je fais autre chose
}

const note = prompt("Quelle est votre note ?");

// if (note >= 15) {
//   alert("Reçus avec mention");
// } else if (note < 15 && note >= 10) {
//   alert("Reçus mais tu aurais pu faire mieux");
// } else {
//  alert("Tu es vraiment mauvais !!!");
// }

// Condition ternaire
// verification ? true : false

let childAge = 17;
childAge > 18 ? console.log("Vous pouvez parier") : console.log("Interdit");

// switch
