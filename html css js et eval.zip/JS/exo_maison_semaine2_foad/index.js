// Exercice 1
// Fonction qui convertie les années en mois
function yearsToMonth(years) {
  return "Il y a : " + years * 12 + " mois dans " + years + " année(s)!";
}
console.log(yearsToMonth(5));

// Exercice 2
// Fonction qui convertie les années en mois et les années en jours
function conversion(years, day) {
  return day === "non"
    ? "Il y a : " + years * 12 + " mois dans " + years + " année(s)!"
    : "Il y a : " + years * 365 + " jours dans " + years + " année(s)!";
}

console.log(conversion(12, "oui"));

// Exercice 3
// Fonction qui convertie les années en mois sur plusieurs parametre
function unlimitedConversionYears(...years) {
  for (let i = 0; i < years.length; i++) {
    console.log(
      "Il y a : " + years[i] * 365 + " jours dans " + years[i] + " année(s)!"
    );
  }
}

unlimitedConversionYears(33, 42, 54, 28);
unlimitedConversionYears(33, 42, 54, 28, 22, 17, 12);
