// Exercice 1

let a = 10;
a = a * 2;
a += 5;

console.log(a);

// Exercice 2

let x = 8;
let y = 8;

console.log(x == y);
console.log(x === y);
console.log(x > y);
console.log(x <= y);
console.log(x >= 5 && x <= 10);
console.log(x <= 5 || x >= 10);

// Exercice 3

let score = 10;
score >= 10 ? console.log("Reussi") : console.log("Echoué");

// Exercice 4

for (let i = 0; i <= 10; i++) {
  if (i != 5) {
    console.log(i + " multiplié par 7 = " + i * 7);
  }
}

// Exerice 5

let sum = 0;

for (let i = 0; i <= 20; i++) {
  sum += i;
}
console.log("Le resultat est de : " + sum);

// Exerice 6

let sum2 = 0;

for (let i = 0; i <= 16; i++) {
  if (i % 2 === 0) {
    sum2 += i;
  }
}
console.log("Le resultat est de : " + sum2);

sum2 = 0;

for (let i = 0; i <= 16; i = i + 2) {
  sum2 += i;
}
console.log("Le resultat est de : " + sum2);

// Exercice 7

let w = 12;
let z = 4;
let operation = "plus";

if (operation === "plus") {
  console.log(w + z);
} else if (operation === "soustration") {
  console.log(w - z);
} else if (operation === "multiplication") {
  console.log(w * z);
} else if (operation === "division") {
  console.log(w / z);
} else {
  console.log("Opération inconnue");
}
