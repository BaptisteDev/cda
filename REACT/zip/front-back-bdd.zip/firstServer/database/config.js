module.exports = {
  mongoDb: {
    uri: "mongodb+srv://<username>:<password>@cluster0.hqoles9.mongodb.net/expensetrack?retryWrites=true&w=majority",
  },
};
