import React from "react";

export default function Data() {
  return <div>Data</div>;
}
