import { createContext } from "react";

export const ExpanseContext = createContext(null);
