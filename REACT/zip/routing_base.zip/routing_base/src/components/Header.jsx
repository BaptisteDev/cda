import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function Header() {
  const { user, logout } = useContext(AuthContext);

  return (
    <header
      className={`h-[58px] px-2 py-4 bg-white shadow-2xs text-blue-600 flex flex-row items-center w-full`}
    >
      <div className="grow">
        <a href="#">
          <strong>My App</strong>
        </a>
      </div>
      <ul>
        {user ? (
          <>
            <a className="mr-4" href="#" onClick={logout}>
              <span>Déconnexion</span>
            </a>
            <a className="mr-4" href="#">
              <span>Profile</span>
            </a>
          </>
        ) : (
          <>
            <a className="mr-4" href="#">
              <span>Insription</span>
            </a>
            <a className="mr-4" href="#">
              <span>Connexion</span>
            </a>
          </>
        )}
      </ul>
    </header>
  );
}
