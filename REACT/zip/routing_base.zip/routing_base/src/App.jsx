import Header from "./components/Header";
import Login from "./pages/forms/Login";

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-100 w-full">
      <Header />
      <div className="flex flex-col flex-1 justify-center items-center w-full">
        <Login />
      </div>
    </div>
  );
}

export default App;
