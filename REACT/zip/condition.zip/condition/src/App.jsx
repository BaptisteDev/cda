import "./App.css";
import Articles from "./Articles";
import Header from "./Header";

function App() {
  return (
    <div className="flex flex-col">
      <Header />
      <Articles />
    </div>
  );
}

export default App;
