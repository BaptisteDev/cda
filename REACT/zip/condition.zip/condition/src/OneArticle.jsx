import React from "react";

export default function OneArticle() {
  return (
    <div className="product-card">
      <img src={article.image} alt={article.name} className="product-image" />
      <div className="product-info">
        <h2 className="product-name">{article.name}</h2>
        <p className="product-price flex-grow">{article.price}</p>
      </div>
    </div>
  );
}
