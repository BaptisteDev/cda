const Header = () => {
  return (
    <header className="bg-white shadow-md p-4 flex flex-row justify-between items-center">
      <span className="text-xl font-bold text-red-500">Sport</span>
      <nav className="flex space-x-6">
        <a href="#" className="text-gray-600 hover:text-black">
          Inscription
        </a>
        <a href="#" className="text-gray-600 hover:text-black">
          Connexion
        </a>
      </nav>
    </header>
  );
};

export default Header;
