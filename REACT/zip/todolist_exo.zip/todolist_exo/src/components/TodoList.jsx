import OneTodo from "./OneTodo";
import EditTodo from "./EditTodo";

export default function TodoList({
  todoList,
  deleteTodo,
  toggleTodo,
  toggleEditTodo,
  saveTodo,
  cancelEditTodo,
  editError,
}) {
  return todoList.length ? (
    <ul>
      {todoList.map((todo) =>
        todo.edit ? (
          <EditTodo
            key={todo.id}
            todo={todo}
            saveTodo={saveTodo}
            cancelEditTodo={() => cancelEditTodo(todo.id)}
            editError={editError} // Transmission de l'erreur d'édition
          />
        ) : (
          <OneTodo
            key={todo.id}
            todo={todo}
            deleteTodo={deleteTodo}
            toggleTodo={() => toggleTodo(todo.id)}
            toggleEditTodo={() => toggleEditTodo(todo.id)}
          />
        )
      )}
    </ul>
  ) : (
    <p>Pas de todo pour le moment ...</p>
  );
}
