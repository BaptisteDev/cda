import React, { useState } from "react";
import ExpenseForm from "./components/ExpenseForm";
import ExpenseList from "./components/ExpenseList";

function App() {
  // initialisation d'un tableau avec useState pour stocker les dépenses
  const [expenses, setExpenses] = useState([]);

  console.log(expenses);

  // fonction qui ajoute une dépense : Quel paramètre et quelle syntaxe ?
  const addExpense = (expense) => {
    console.log(expense);
    setExpenses([...expenses, expense]);
  };

  // fonction qui supprime une dépense : Quel paramètre et quelle syntaxe ?
  const deleteExpense = (data) => {
    console.log(data);
    setExpenses(expenses.filter((exp) => exp.description !== data));
  };

  return (
    <div className="max-w-3xl mx-auto p-4 bg-white shadow-md rounded my-8">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-6">
        Suivi des Dépenses
      </h1>
      {/* Ajout des props sur ces composants */}
      <ExpenseForm addExpense={addExpense} />
      <ExpenseList expenses={expenses} deleteExpense={deleteExpense} />
    </div>
  );
}

export default App;
