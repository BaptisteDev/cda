import React from "react";
import ExpenseItem from "./ExpenseItem";

function ExpenseList({ expenses, deleteExpense }) {
  return (
    <div className="flex flex-col gap-4">
      {expenses.length === 0 ? (
        <p>Aucune dépense à afficher</p>
      ) : (
        expenses.map((exp) => (
          <ExpenseItem
            key={exp.description}
            expence={exp}
            deleteExpense={deleteExpense}
          />
        ))
      )}
    </div>
  );
}

export default ExpenseList;
