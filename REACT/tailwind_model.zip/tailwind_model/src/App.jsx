import "./App.css";

function App() {
  return (
    <>
      <h1>Tailwind Version 4 Model</h1>
    </>
  );
}

export default App;
