import React from "react";
import Card from "./Card";

export default function Content() {
  return (
    <div className="flex-fill d-flex flex-wrap justify-content-center">
      <Card />
      <Card />
      <Card />
      <Card />
      <Card />
      <Card />
      <Card />
    </div>
  );
}
