import React, { useEffect, useState } from "react";
import movies from "./data.json";
import Movie from "./Movie";

const MoviesList = () => {
  return (
    <div className="w-full">
      <ul className="flex flex-wrap">
        {movies.map((movie) => (
          <Movie key={movie.id} movie={movie} />
        ))}
      </ul>
    </div>
  );
};

export default MoviesList;
