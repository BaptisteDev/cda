// import "./App.css";

function App() {
  return (
    <>
      <h1 className="text-3xl font-bold underline">Tailwind</h1>
    </>
  );
}

export default App;
