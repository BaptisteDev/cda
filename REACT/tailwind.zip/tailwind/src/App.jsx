import "./App.css";
import Colors from "./Colors";
import LayoutFlex from "./LayoutFlex";

function App() {
  return (
    // <div className="min-h-72 bg-black sm:bg-red-500 md:bg-yellow-500 lg:bg-green-500 xl:bg-cyan-500 2xl:bg-violet-500 text-white 2xl:text-black">
    //   <p>640 - NOIRE</p>
    //   <p>SM 640 + ROUGE</p>
    //   <p>MD 768 + JAUNE</p>
    //   <p>LG 1024 + VERT</p>
    //   <p>XL 1280 + CYAN</p>
    //   <p>2XL 1536 + VIOLET</p>
    // </div>
    <Colors />
    // <LayoutFlex />
  );
}

export default App;
