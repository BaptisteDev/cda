import "./App.css";

function Fonts() {
  return (
    <div className="m-auto h-screen w-1/2">
      <p class="m-5 font-sans">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa vero
        aperiam quo excepturi rerum expedita itaque aspernatur ea natus earum
        facere, quia fugiat eligendi assumenda blanditiis maxime deserunt, qui
        veniam!
      </p>
      <p class="m-5 font-serif">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa vero
        aperiam quo excepturi rerum expedita itaque aspernatur ea natus earum
        facere, quia fugiat eligendi assumenda blanditiis maxime deserunt, qui
        veniam!
      </p>
      <p class="m-5 font-mono">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa vero
        aperiam quo excepturi rerum expedita itaque aspernatur ea natus earum
        facere, quia fugiat eligendi assumenda blanditiis maxime deserunt, qui
        veniam!
      </p>
      <p class="m-5 text-xl/8">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa vero
        aperiam quo excepturi rerum expedita itaque aspernatur ea natus earum
        facere, quia fugiat eligendi assumenda blanditiis maxime deserunt, qui
        veniam!
      </p>
      <p class="m-5 text-base/relaxed">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa vero
        aperiam quo excepturi rerum expedita itaque aspernatur ea natus earum
        facere, quia fugiat eligendi assumenda blanditiis maxime deserunt, qui
        veniam!
      </p>
    </div>
  );
}

export default Fonts;
