import React from "react";
import Logement from "./section/Logement";

export default function Content() {
  return (
    <div className="flex-auto">
      <Logement></Logement>
    </div>
  );
}
